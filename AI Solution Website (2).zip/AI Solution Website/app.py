# from flask import Flask, render_template, request, redirect, url_for, jsonify

# app = Flask(__name__, template_folder='templates')  

# # Home Page Route
# @app.route('/')
# def index():
#     return render_template('index.html')

# # Services Page Route
# @app.route('/services')
# def services():
#     return render_template('services.html')

# # Contact Us Page Route
# @app.route('/contact')
# def contact():
#     return render_template('contact.html')

# # Case Studies Page Route
# @app.route('/case-studies')
# def case_studies():
#     return render_template('case_studies.html')

# # Admin Login Panel Route
# @app.route('/admin', methods=['GET', 'POST'])
# def admin_login():
#     if request.method == 'POST':
#         username = request.form.get('username')
#         password = request.form.get('password')
#         # Replace this with secure authentication logic
#         if username == "admin" and password == "password":  # Example credentials
#             return redirect(url_for('admin_dashboard'))
#         return render_template('admin_login.html', error="Invalid credentials. Try again.")
#     return render_template('admin_login.html')

# # Admin Dashboard Route
# @app.route('/admin/dashboard')
# def admin_dashboard():
#     return "Welcome to the Admin Dashboard!"

# # Chatbot Simulation Route
# @app.route('/chatbot', methods=['POST'])
# def chatbot():
#     try:
#         user_message = request.json.get('message', '')
#         if not user_message:
#             return jsonify({"error": "Message cannot be empty"}), 400
#         # Logic for chatbot response can be added here
#         response_message = f"Chatbot Response to: {user_message}"
#         return jsonify({"response": response_message})
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500

# # Run the Flask app
# if __name__ == '__main__':
#     app.run(debug=True)






















# # from flask import Flask, render_template, request, redirect, url_for

# # app = Flask(__name__)

# # # # Home Page Route
# # # @app.route('/')
# # # def index():
# # #     return render_template('index.html')
# # # Home Page Route
# # @app.route('/')
# # def index():
# #     return render_template('index.html')

# # # Services Page Route
# # @app.route('/services')
# # def services():
# #     return render_template('services.html')

# # # Contact Us Page Route
# # @app.route('/contact')
# # def contact():
# #     return render_template('contact.html')

# # # Case Studies Page Route
# # @app.route('/case-studies')
# # def case_studies():
# #     return render_template('case_studies.html')
# # # Events Page Route
# # @app.route('/Events')
# # def Events():
# #     return render_template('Events.html')


# # # Admin Login Panel Route
# # @app.route('/admin', methods=['GET', 'POST'])
# # def admin_login():
# #     if request.method == 'POST':
# #         username = request.form.get('username')
# #         password = request.form.get('password')
# #         # Add logic for admin authentication here
# #         if username == "admin" and password == "password":  # Replace with secure check
# #             return redirect(url_for('admin_dashboard'))
# #         return "Invalid credentials. Try again."
# #     return render_template('admin_login.html')

# # # Admin Dashboard (Placeholder)
# # @app.route('/admin/dashboard')
# # def admin_dashboard():
# #     return "Welcome to the Admin Dashboard!"

# # # Chatbot Simulation Route
# # @app.route('/chatbot', methods=['POST'])
# # def chatbot():
# #     user_message = request.json.get('message', '')
# #     # Add logic for chatbot response here
# #     response_message = f"Chatbot Response to: {user_message}"
# #     return {"response": response_message}

# # # Run the Flask app
# # if __name__ == '__main__':
# #     app.run(debug=True)
# # from flask import Flask, render_template, request, redirect, url_for

# # app = Flask(__name__)

# # # Home Page Route
# # @app.route('/')
# # def index():
# #     return render_template('index.html')

# # # Services Page Route
# # @app.route('/services')
# # def services():
# #     return render_template('services.html')

# # # Contact Us Page Route
# # @app.route('/contact')
# # def contact():
# #     return render_template('contact.html')

# # # Case Studies Page Route
# # @app.route('/case-studies')
# # def case_studies():
# #     return render_template('case_studies.html')
# # # Events Page Route
# # @app.route('/Events')
# # def Events():
# #     return render_template('Events.html')


# # # Admin Login Panel Route
# # @app.route('/admin', methods=['GET', 'POST'])
# # def admin_login():
# #     if request.method == 'POST':
# #         username = request.form.get('username')
# #         password = request.form.get('password')
# #         # Add logic for admin authentication here
# #         if username == "admin" and password == "password":  # Replace with secure check
# #             return redirect(url_for('admin_dashboard'))
# #         return "Invalid credentials. Try again."
# #     return render_template('admin_login.html')

# # # Admin Dashboard (Placeholder)
# # @app.route('/admin/dashboard')
# # def admin_dashboard():
# #     return "Welcome to the Admin Dashboard!"

# # # Chatbot Simulation Route
# # @app.route('/chatbot', methods=['POST'])
# # def chatbot():
# #     user_message = request.json.get('message', '')
# #     # Add logic for chatbot response here
# #     response_message = f"Chatbot Response to: {user_message}"
# #     return {"response": response_message}

# # # Run the Flask app
# # if __name__ == '__main__':
# #     app.run(debug=True)






from flask import Flask, render_template, request, redirect, url_for, jsonify

# Initialize the Flask app
app = Flask(__name__, template_folder='templates')  

# Home Page Route
@app.route('/')
def home():
    return render_template('home.html')

# Services Page Route
@app.route('/services')
def services():
    return render_template('services.html')

# Contact Us Page Route
@app.route('/contact')
def contact():
    return render_template('contact.html')

# Case Studies Page Route
@app.route('/case-studies')
def case_studies():
    return render_template('case-studies.html')

# Events Page Route
@app.route('/events')  # Ensure template name matches 'events.html'
def events():
    return render_template('events.html')

# Admin Login Panel Route
@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        # Basic admin authentication (replace with secure logic for production)
        if username == "admin" and password == "password":
            return redirect(url_for('admin_dashboard'))
        return render_template('admin_login.html', error="Invalid credentials. Try again.")
    return render_template('admin_login.html')

# Admin Dashboard Route (Placeholder)
@app.route('/admin/dashboard')
def admin_dashboard():
    return "Welcome to the Admin Dashboard!"

# Chatbot Simulation Route
@app.route('/chatbot', methods=['POST'])
def chatbot():
    user_message = request.json.get('message', '')
    if not user_message:
        return jsonify({"error": "Message cannot be empty"}), 400
    # Add chatbot logic here
    response_message = f"Chatbot Response to: {user_message}"
    return jsonify({"response": response_message})

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)
